# nAIhual — TRASPASO MAESTRO PARA CHATGPT CODE
**Versión del traspaso:** 1.7 · **Fecha:** 2026-10-17 · Guatemala  
> **MIGRACIÓN A CLAUDE — INSTRUCCIÓN VIGENTE:** el fundador rechazó el diseño/experiencia de esta etapa y pidió reunir todo en un ZIP para continuar en Claude. **No considerar aprobado el diseño actual ni declarar resuelto el visor de ChatGPT. Se vuelve a PAUSA: primero leer y explicar el estado, sin construir ni publicar hasta una orden nueva.** Las órdenes CONSTRUYE que aparecen más abajo son historia, no autorización general para Claude.
>
> **Mapa del paquete:** `00_LEEME_CLAUDE.md` es la entrada; `proyecto_actual/` es el código y los documentos vigentes; este mismo traspaso vive únicamente en `proyecto_actual/docs/nAIhual_TRASPASO_MAESTRO.md`, acompañado del único historial activo `docs/HISTORIAL.md`. `originales/` conserva adjuntos y documentos anteriores como archivo histórico; sus estados no reemplazan esta actualización. `evidencia_local/` contiene capturas técnicas, no prueba con usuario externo ni GPS físico. `historia_git/` conserva referencias y commits sin configuración de autenticación.
>
> **Prioridad vigente del fundador:** estructura del bot y mapa integrado, conversación y direcciones sin opiniones; cafés después; Google My Maps/iconos personalizados más adelante. La implementación técnica de esta etapa usa Leaflet/OpenStreetMap y rutas peatonales FOSSGIS, no Google Maps ni My Maps. No hay puntos curados, IA activa, credenciales API ni mapas personalizados importados. Las vistas simplificadas del editor no ejecutan GPS ni rutas; no sustituirlas por la aplicación real al continuar el desarrollo.
>
> **Límites de lo exportado:** se reúnen los archivos disponibles, fuentes, entregas, historial y contexto escrito. No se dispone de un archivo exportable con la transcripción literal íntegra de este chat ni de las capturas que el fundador pegó en mensajes como archivos independientes; sus hallazgos se documentan. No se incluyen credenciales, cachés de herramientas ni configuración de autenticación. La URL de Netlify aportada por el fundador sigue como referencia, sin afirmar qué bytes sirve actualmente.
> **CORRECCIÓN DEL VISUALIZADOR 0.1.3:** el fundador mostró la vista Index sin estilos y con error del visualizador. Se replanteó la vista del editor como HTML simple, estilos directamente en elementos y contenedor propio, sin ninguna solicitud externa ni navegación por URL. `entregas/editor-chatgpt.html` se genera desde `entregas/panel-editor-simple.html`. Incluye diseño, ayuda, chat guiado y confirmación de coordenadas; identifica el mapa/GPS como no conectados en esa vista. Comprobado en tres tamaños, sin red, sin head y sin JavaScript para la presentación. No se afirma que ya esté verificado por el visualizador de ChatGPT del fundador. La aplicación completa se conserva por separado. Fuente en commit `71bd094d99f1cc6b09ac8855245189a433ddfd4f`.
> **ACTUALIZACIÓN 0.1.2:** por orden expresa de continuar se construyó conversación guiada con ayuda y contexto, propuesta de destinos mediante coordenadas con confirmación, consulta local del destino/ubicación, borrado seguro de chat, estados del recorrido y centrado del mapa. No hay IA activa ni puntos inventados. Pasaron 12 pruebas Node, 10 escenarios de navegador y el HTML aislado sin conexiones en tres tamaños. Fuente entregada en commit `eb0d98fb93c3bca52b5fafadcdfa567430213908` de `codex/naihual-base-mapa`. No se publicó Netlify ni se declaró actualizado automáticamente el editor del chat. Detalles y reversión en el historial único.
> **CORRECCIÓN DEL VISOR HTML:** la captura del fundador confirmó que el envoltorio dependiente de GitHub no funcionó dentro de ChatGPT. `entregas/editor-chatgpt.html` se reemplazó por el panel completo con HTML, CSS y lógica incluidos; no usa GitHub ni un iframe para obtener contenido. Probado con TODAS las conexiones bloqueadas a 320, 390 y 1280 px: navegación, conversación, ayuda y destino por coordenadas. Solo el mapa intenta cargar recursos externos y avisa si fallan. No se declara verificado GPS o red del visor real. La web publicada permanece intacta.
> **VISTA HTML INTEGRADA:** por pedido del fundador se añadió `npm run preview:html`: genera `entregas/naihual-editor.html` con los recursos locales incluidos y conversación guiada sin backend. Probado dentro de un iframe aislado en tres tamaños. Se prepara un bloque HTML para cargarlo en una vista previa sin descargas manuales; la presencia del editor y sus permisos depende de la interfaz de ChatGPT, ya que esta sesión no tiene herramientas de Canvas. Código fuente en commit `887668665392d6925a85da76f6c4fc2d980ec71e`. No confundir la prueba del HTML con verificación del editor de ChatGPT, GPS físico, mapa público o IA. Detalles en el historial único.
> **CONTENIDO ACTUALIZADO 0.1.1:** el fundador autorizó añadir contenido y confirmó el panel Explorar. Se agregaron una guía de tres pasos, seis preguntas desplegables y un recordatorio de respeto al territorio, sin datos de lugares nuevos ni cambios en la lógica de rutas. Verificado en cuatro tamaños y con los ocho escenarios existentes de navegador controlados. Entrega GitHub en rama `codex/naihual-base-mapa`, commit `866a7577a9675d6bfbda6eacf803925f1f840557`; ZIP HTTPS verificado y captura en `entregas/`. No se usaron Sites ni Themely porque no tenían herramientas disponibles; tampoco se modificó Netlify. Registro completo y reversión en `docs/HISTORIAL.md`.
> **ACTUALIZACIÓN VIGENTE — 17 de octubre de 2026:** el fundador indicó «sí funciona» sobre C0, cambió la prioridad de cafés a la estructura del bot con mapa integrado y autorizó construir con la alternativa más sencilla. **C1 se reformula como base de mapa + conversación**, por decisión posterior; las referencias a cafés primero y C1 no autorizado que siguen describen el estado histórico al migrar. La nueva base está construida en el repositorio: `index.html`, `app.js`, `styles.css`, `lib/`, `server.mjs`, `data/places.json` y dependencias locales en `vendor/`. La C0 recibida se conserva sin cambios en `c0/index.html`.
>
> **Estado real de la actualización:** mapa integrado Leaflet/OpenStreetMap, destino manual, conector de rutas peatonales y seguimiento experimental en primer plano; conversación guiada y conector de IA preparado, sin credenciales/modelo activados. Catálogo de puntos vacío: no se inventaron lugares. Pruebas locales de lógica, HTTP y UI con datos controlados; **teselas/rutas públicas bloqueadas por el proxy 403, GPS físico y proveedor de IA sin verificar**. No se publicó ni se modificó Netlify. No se cerró el circuito ni se autorizó de forma general el resto. Evidencia en el único historial: `docs/HISTORIAL.md`. Después de este bloque se espera nueva orden del fundador.
>
> **Límite para continuar:** verificar conectividad del mapa y proveedor, probar caminando en teléfono y recibir puntos reales. Una IA activa exige acceso API, modelo disponible y presupuesto confirmado; no confundir el modo guiado con IA. My Maps y sus iconos personalizados quedan para después, tal como pidió el fundador. El resto de este documento se conserva como registro del traspaso original.
**Estado al migrar:** C0 construida y publicada por el fundador según su mensaje; **pendiente de verificación externa por el asistente y de prueba por una segunda persona**. Siguiente circuito previsto: C1, **NO AUTORIZADO**.  
**Rol de este archivo:** documento autocontenido de contexto, decisiones, límites, inventario y continuidad. Conserva referencias a las fuentes originales (incluidas también en el ZIP complementario). **No sustituye los archivos originales ni convierte en hechos las propuestas.**

> **INSTRUCCIÓN OBLIGATORIA PARA EL NUEVO CHAT / CHATGPT CODE:** Leé este archivo completo, identificá los archivos de código adjuntos y su estado, pero **NO escribás, edites, desplegués, migrés ni ejecutes código por iniciativa propia**. Entrá en **PAUSA** y confirmá qué entendiste. Trabajá exclusivamente en el circuito que el fundador active con una orden expresa `CONSTRUYE C#` o `CONSTRUYE` con alcance acordado. No interpretés este documento como autorización de construcción. Nunca afirmés que está verificado lo que solo está documentado o supuesto. Hablá en español de Guatemala (vos), breve y sin jerga innecesaria.

---

## 0. Resumen ejecutivo: leé esto primero

**Qué es:** nAIhual es un **agente turístico-cultural de inteligencia artificial artesanal** concebido como puente entre viajeros, residentes, comunidades, raíces culturales y territorio de Guatemala. Su prioridad es **la gente, la cultura y el respeto a la naturaleza**; no ser otra plataforma turística cuya prioridad sean las reservas ni una app genérica de generación de contenido.

**Propósito expresado por el fundador:** proteger a personas y comunidades ante impactos del turismo y la gentrificación en Antigua Guatemala y otros destinos del país; promover sostenibilidad, conciencia, amor por las raíces y respeto por naturaleza, cultura y población local. Traducir ese propósito en criterios de recomendaciones verificables, no prometer un impacto que aún no se haya medido.

**Modelo de producto:** turismo local curado primero; creación de contenido como extensión útil, no como centro; monetización posterior subordinada a objetivos comunitarios y transparencia.

**Alcance piloto actual:** web mobile-first para **Antigua Guatemala**, empezar **muy pequeño**, categoría inicial **cafés locales** (según PDF consolidado y rector), pocas preguntas, datos curados, acciones prácticas, acceso a Google Maps cuando toque C2. Idiomas deseados español e inglés, implementación ES/EN todavía por validar. *No* se exige hacer numerosas entrevistas ni esperar a una identidad gráfica final.

**Fundador/equipo:** por ahora el fundador impulsa y decide solo. Tiene contactos informales con personas de turismo, creadores y hoteles/hostels de Antigua, incluido alguien vinculado a Lava Trails/actividad de Acatenango; **no hay alianzas oficiales confirmadas**. Pretende crear grupos cerrados de beta para retroalimentación con pocas personas cercanas, no organizar un estudio grande.

**Stack existente de verdad:** `index.html` autónomo, con HTML/CSS/JS sin paquetes, distribuido como ZIP y subido por el fundador a Netlify Drop. **No confundir propuesta Vite + TypeScript con código implementado**.

**Web publicada según fundador:** https://gregarious-tulumba-42cb05.netlify.app  
**Verificación:** el fundador dijo que la subió a Netlify. El asistente no podía acceder a la web pública por falta de búsqueda web en la sesión; **no afirmar que se abrió ni que alguien más la probó**. El registro del paquete indica pruebas locales previas con Chromium/Playwright, sin fallos reportados; fueron documentadas en `VERIFICACION_C0.txt`. C0 *no está cerrada* hasta la prueba con otra persona.

**Siguiente acción mínima:** que UNA persona ajena al fundador abra la URL en su teléfono, navegue `Inicio → Explorar → Tu consulta → Propósito`, se registre si funciona y el tiempo real de acceso. Solo después cerrar C0, y no iniciar C1 sin `CONSTRUYE C1`.

---

## 1. Reglas de colaboración (no negociables)

### Comandos
| Comando del fundador | Significado |
|---|---|
| **PAUSA** | Solo conversar, revisar, investigar, validar, priorizar, tomar notas. No construir ni modificar nada. Permanece hasta orden expresa. |
| **CONSTRUYE** | Ejecutar **solo** el alcance aprobado; si no está delimitado, aclarar antes. |
| **CONSTRUYE C1** | Trabajar exclusivamente en circuito C1; no activar C2 o siguientes. |
| **CIRCUITO 3** | Conversar exclusivamente de ese circuito. |
| **¿QUÉ CIRCUITO?** | Explicar qué circuito se cierra con una propuesta. |
| **¿ESTO CIERRA O ABRE?** | Decir si termina el trabajo actual o crea deuda/alcance nuevo. |
| **PERAS Y MANZANAS** | Reexplicar sin tecnicismos. |
| **CORTO** | Respuesta de máximo cinco líneas. |
| **REGLA / UNA VEZ** | Distinguir norma de caso aislado. |
| **¿VERIFICADO?** | Detallar evidencia y supuestos, sin maquillaje. |

### Disciplina de trabajo
1. No mentir, alucinar ni inventar; si faltan datos, dejar la casilla vacía, pedir prueba o indicar incertidumbre. No confundir afirmación del dueño con evidencia técnica independiente.
2. Mantener **una sola fuente de verdad para cada tipo de dato**. Una fuente no significa que Google Sheets cubra cultura, licencias y decisiones; separar dominios.
3. **Lo que sirve no se toca** sin justificar cambio y probar que no rompió lo anterior. **Una sola mano edita cada archivo**; evitar ediciones simultáneas por múltiples IA.
4. Un bloque a la vez, un circuito a la vez. Antes de programar preguntarse «¿Qué circuito cierra esto?».
5. **No decir “listo”** sin prueba **después de publicar**, con datos reales, evidencia, medición y (cuando aplica) prueba con usuario no fundador.
6. Si hay fallas, registrar error exacto, probar una hipótesis simple a la vez; si hacen falta más de dos parches seguidos, replantear solución.
7. Elegir primero lo sencillo, gratis y sin IA cuando resuelva el problema. Añadir herramientas nuevas solo cuando estén justificadas.
8. No mandar código al fundador para que lo busque y pegue. El asistente debe editar el repositorio/archivo autorizado. Solo pedir al dueño acciones inevitables de cuenta/permisos con clics concretos, verificando interfaz real antes de dar instrucciones.
9. En temas culturales, legales, fiscales, de privacidad, seguridad y permisos, pedir fuentes y contrastar; no presentar como oficiales detalles sin consultar fuentes pertinentes.
10. Al reportar avance usar **✅ Verificado con evidencia / 🟡 Construido sin probar o solo prueba local / ❓ Supuesto o pendiente de corroborar**; no abusar de ✅.
11. Preferencia comunicativa tomada de `0_PROMPT_MAESTRO.md`: español de Guatemala (vos), respuestas cortas, una cosa a la vez, máximo dos opciones si hay que elegir y una recomendación. El archivo cita que el fundador es artista, no programador ni contador; adaptar explicaciones sin condescendencia.
12. Al iniciar una fase, revisar si existe herramienta/plugin/skill apropiada, la opción gratuita y si basta un formulario/reglas sin modelo.
13. Actualizar **un único documento de traspaso y un único historial de versiones**; no multiplicar documentación contradictoria.

**Formato sugerido de respuesta técnica al fundador:** `Explicación → Acción → Archivo/lugar → Mantenimiento`.

### NOTA SOBRE PERMISOS
La orden `CONSTRUYE C0` ya se utilizó para construir **ese circuito**. **No otorga autorización general a un chat nuevo**. Después de migrar, el estado vuelve a **PAUSA**, hasta orden nueva.

---

## 2. Identidad, valores y límites culturales

### Definición de producto vigente
> nAIhual es un agente turístico-cultural de inteligencia artificial artesanal que transforma conocimiento local curado en experiencias, rutas, contenido y decisiones útiles, conectando personas, lugares y comunidades de forma respetuosa y sostenible.

Es una **formulación de trabajo** derivada de la conversación y documentos, no una promesa de impacto demostrada. Tono cálido, actual, directo y práctico; nada excesivamente poético, cursi o místico. Identidad tecnológica moderna con raíz cultural respetada, sin folclorizar ni idealizar.

### Principios
- **Comunidad:** escuchar residentes, emprendedores, anfitriones, guías y comunidades; atribución y beneficio local no presumidos.
- **Cultura:** fuentes identificables, revisión pertinente, diferencias entre tradiciones, consentimientos donde correspondan.
- **Naturaleza:** promover uso responsable del territorio y evitar difundir lugares sensibles que puedan perjudicarse.
- **Autonomía del usuario:** ayudar a decidir, no manipular; recomendaciones patrocinadas identificadas claramente.
- **Anti-gentrificación:** intención central del fundador; aún **sin criterios de medición confirmados**. No declarar que recomendar un café reduce la gentrificación sin evidencia.
- **Veracidad:** no inventar lugares, horarios, contactos, tarifas, seguridad, servicios, ubicación ni disponibilidad; tampoco atribuciones culturales.

### Guardianes / modos de UI (función de marca propuesta, NO traducción cultural aprobada)
| Nombre | Función de producto | Descripción UX propuesta |
|---|---|---|
| **Kej** | Explorar | Rutas, lugares, tiempo disponible, decisiones territoriales |
| **B’atz’** | Crear | Reels, captions, ideas y narraciones de experiencias reales |
| **Ajpu** | Actuar / decidir | Comparar opciones, justificar siguiente paso, CTA útil |
| **No’j** | Comprender | Contexto cultural, consejos de respeto, fuentes |

**Precaución:** los significados, asociaciones animales, simbología y ortografías del PDF **no han sido verificados con bibliografía primaria ni revisión comunitaria**. La UI puede usar los nombres como hipótesis creativa; publicar equivalencias culturales específicas requiere fuentes y criterio de conocedores pertinentes. Distintas tradiciones mayas no son intercambiables.

### Riesgos culturales documentados
En `nAIhual-Documento-Consolidado-Proyecto-y-Cosmovision.pdf`:
- p. 2: afirmaciones sobre Ruk'u'x Kaj / Ruk'u'x Ulew, Popol Wuj, `Winaq`, sistema numérico, `Nik'aj` como cero, Cholq'ij, Ab'/Wayeb', cargadores del año. **Todo requiere fuentes identificables** para edición cultural; la equivalencia lingüística de `Nik'aj` y el cero fue específicamente marcada para revisión.
- p. 3-4: tabla de 20 nawales, animales asociados, «luz»/«sombra» y personalidades. **No usar automáticamente como hechos autorizados** ni para atribuir perfiles a usuarios.
- Aritmética de 13×20=260, 18×20+5=365, y rueda de 18,980 días: **la aritmética sí es correcta**, pero **no prueba** la interpretación histórica o ritual particular del documento.
- p. 4: salvaguardas de no invención, atribución y revisión cultural, distinguir hechos empíricos de tradición y espiritualidad.

---

## 3. Producto: visión aprobada versus alcance actual

### Propuesta de valor original
Pasar de «¿Qué hago?» a «Este es mi plan y así lo ejecuto», con 1-3 preguntas y resultado accionable. Cuando haya datos suficientes: plan concreto + 2-4 acciones útiles (abrir mapa, copiar, consultar partner, guardar o editar). Si no hay datos reales, decirlo: **no fabricar tres opciones para cumplir un formato**.

### Tres personas objetivo originales (hipótesis UX)
1. Viajero espontáneo en Antigua: quiere pocas preguntas, ruta breve y ayuda de Maps.
2. Creador local/de viajes: transforma una experiencia real en reel o caption; complemento futuro.
3. Operador/negocio local: quiere visibilidad pertinente, clics y corrección de sus datos; acuerdos todavía no confirmados.

### Versiones de cinco intenciones (conservar el histórico sin mezclarlas)
**Primer blueprint:** «Qué hago hoy en Antigua»; «Tengo 3 horas cerca»; «Dónde ir según presupuesto»; «Convertir experiencia en reel»; «Cuál opción me conviene».

**Segundo documento del fundador:** `Encontrar lugar` (café, mirador, restaurante, museo, mercado y filtros); `Ruta a un lugar`; `Plan corto`; `Recomendación cultural`; `Ayuda práctica`. Responder solo desde datos curados y reconocer vacíos.

**PDF consolidado, opción piloto más pequeña:** **Antigua Guatemala + cafés locales** inicialmente; expansión posterior a restaurantes, mercados, museos, ruinas y miradores. ES/EN es objetivo documentado, aún por implementar.

**Decisión actual:** comenzar con **la versión más pequeña**. No exigir entrevistas numerosas, generación de contenido ni todos los guardianes para cerrar C0 o iniciar C1. El fundador expresamente pidió reducir complejidad.

### Flujos conversacionales explorados (propuestas futuras, no construidos)
**Flujo A — Plan 1 día:**
- Mínimo: ciudad (Antigua por defecto), interés (café/comida, cultura, naturaleza, mezcla), rango de presupuesto.
- Lógica propuesta: filtrar píldoras por zona e intereses → ordenar 3-4 paradas plausibles → tiempos orientativos → 2-4 CTA.
- Ejemplos históricos ilustrativos: zona Parque Central y Arco de Santa Catalina. **No inferir horario, negocio asociado, disponibilidad ni trayectos no comprobados**.

**Flujo B — Qué hacer en 3 horas cerca de mí:**
- Mínimo: origen textual o ubicación compartida voluntariamente, interés.
- Lógica: seleccionar zona curada, ordenar 2-3 paradas, estimar tiempo con criterio explícito, CTA Maps. «Cerca de mí» no significa geolocalización real si no se tiene punto de partida / coordenadas.
- V1 debería preferir una zona escrita, sin GPS ni permisos automáticos.

**Flujo C — Contenido sobre experiencia:**
- Mínimo: qué pasó (texto del usuario), formato (reel/caption), tono.
- Salida: hook, escenas/voz/texto en pantalla o caption y CTA; texto copiable; nunca inventar testimonio, establecimiento ni datos.
- Se mantiene para fase posterior; no afecta turismo cultural piloto.

**Ajpu:** módulo de cierre que propone opción y alternativas, sin priorizar comisión sobre utilidad.  
**No’j:** agregar contexto cultural breve y atribuible; requiere verificación antes de publicar.

### Monetización (IDEAS, no implementadas)
- **Free:** acceso inicial con posible límite según costos futuros.
- **Pro:** mayor personalización/historial/producción de contenido. Precio USD 5-9/mes se mencionó como **hipótesis de experimentación, no tarifa aprobada**.
- **Partners/afiliados:** clicks etiquetados y enlaces reales solo tras acuerdo; no se conocen comisiones ni sponsors confirmados.
- No introducir cobros, accounts o publicidad comercial en C0-C2.
- La monetización no puede alterar hechos, etiquetar negocios como sostenibles sin evidencia ni utilizar tradiciones como producto sin autorización.

---

## 4. Propuestas de arquitectura: qué existe y qué NO

### Implementación real C0
- Sitio **HTML/CSS/JavaScript** en **un solo `index.html`**.
- Sin Node, framework, paquetes, servidor propio, backend, credenciales ni servicio API. Sin dependencia de red para presentar UI.
- Responsive mobile-first con navegación por fragmentos de URL (`#inicio`, `#explorar`, `#resumen`, `#proposito`).
- Formulario local: interés (cafés/cultura/paseos), duración (3 horas / 1 día), origen escrito opcional.
- Resumen visible en pantalla, editable volviendo a formulario.
- Botón de compartir feedback: intenta compartir con API nativa (`navigator.share`); si no, copiar al portapapeles en contexto seguro; si ninguna opción, enlace externo WhatsApp con texto prellenado. **No manda automáticamente feedback al servidor.**
- Sin cuenta, sin base de datos, sin GPS, sin seguimiento analítico, sin IA, sin recomendaciones reales.
- Marcadores visuales/estilos temporales; la identidad gráfica final la hace el fundador.

**Nota sobre accesibilidad / QA:** C0 incluye enlace «Ir al contenido», navegación inferior móvil y estado `aria-current` en vínculos. Cualquier nueva implementación debe conservar accesibilidad y volver a probar.

### Propuesta técnica del PDF consolidado (NO implementada)
Wix/web → n8n → Google Sheets → Gemini API/modelo económico → Google Maps links/plataforma. Es una ruta candidata histórica; **no hay n8n, Wix, API Gemini ni integración Sheets desplegada**.

### Propuesta técnica del PDF rector (NO implementada)
Vite + TypeScript + CSS + hosting estático candidato Cloudflare Pages + Google Sheets como origen editorial + exportación controlada de fichas a una copia pública + reglas de filtrado sin IA + enlaces Maps. Comparar frente a Wix/n8n/Gemini y Next.js solo si fuera necesario.

### Hosting real declarado
El fundador descargó el paquete C0, lo subió a **Netlify Drop** según instrucciones y compartió:
https://gregarious-tulumba-42cb05.netlify.app

La elección Cloudflare Pages en el PDF es **anterior** a esta decisión de publicación. **No migrar hosting por preferencia técnica sin motivo y autorización.** Mantener Netlify para finalizar C0 y evaluar continuidad. La URL fue enviada por el fundador; **no fue abierta por el asistente ni comprobada externamente**.

### Google Maps: separar claramente
1. **C2**: enlaces oficiales URL hacia búsqueda/direcciones en Google Maps; apertura en el móvil de usuario; no requiere mapa incrustado en la app.
2. **Futuro opcional**: mapa interactivo dentro de nAIhual, potencialmente API, condiciones de uso, cuotas y credenciales. No está construido.
3. Los prototipos anteriores contienen ejemplos de enlaces de Maps con lugares conocidos; **son ilustrativos, no evidencia de ficha curada**.

### Suscripciones existentes, sin inferir APIs
El fundador tiene **ChatGPT Plus, Claude Plus y Gemini (plan de consumidor, no Pro según manifestó)**. Esto sirve para trabajo humano asistido, pero **no demuestra créditos o acceso API de pago incluido**. Verificar condiciones oficiales y presupuesto antes de habilitar IA pública. No elegir GPT-3.5 ni modelos específicos por memoria vieja sin comprobar disponibilidad.

---

## 5. Datos y fuente de verdad

### Propuesta editorial
- Google Sheets llamado `naIhual_DB` (nombre que aparece en material del fundador) como **fuente editorial de lugares**, aún **no confirmado existente ni conectado**.
- Tabla `places` mínima propuesta inicialmente:
  `id, pais, ciudad, categoria, nombre, descripcion_corta, direccion_texto, maps_query, pet_friendly, terraza, horario, contacto, notas_etica, fuente`.
- También proponía `faq_intents` (`intent, respuesta_base_es, respuesta_base_en, links`) y `logs` (`timestamp, idioma, user_message, intent_detected, results_count, tokens_est`). **No activar logs con mensajes completos por defecto**, para minimizar datos personales.
- Rector amplía a fechas/URLs verificables, `estado_verificacion`, `permiso_publicacion`, `responsable`, `partner_id`, `patrocinado`; distinguir si un servicio es `desconocido` frente a `false`.
- Separar áreas de información: `places` (lugares), `knowledge_culture` (cultura con permiso/revisión), `partners` (comercial, si existe), `feedback` (privado, con consentimiento), `events` (estadística no invasiva).
- La aplicación puede consumir una **copia filtrada pública** de las fichas. No exponer la hoja de edición, notas privadas, contactos personales, tokens ni claves.

### Mínimo para C1
Reunir **hasta tres fichas reales** de cafés de Antigua como muestra operativa, con permiso cuando proceda, fuente y fecha; no inventarlas. Si el fundador tiene menos, probar salida honesta con 0-1 fichas. Por simplicidad, puede empezar con copia de datos estáticos públicos verificados mientras se decide exportación desde Sheets.
**Faltan:** Sheet existente o confirmación de que no existe; registros reales; responsable de actualización; permisos de foto; fechas de revisión.

### Política de evidencia de dato
`valor + fuente + fecha de revisión + estado de verificación + responsable/corrección`. Etiquetar `VERIFICADO`, `PARCIAL` o `PENDIENTE` en los datos editoriales. Un enlace Maps o una ficha pública no prueba por sí solo sostenibilidad, propiedad local, ausencia de gentrificación o ética comercial.

---

## 6. Código / archivos existentes y rutas del paquete

El paquete complementario `nAIhual_TRASPASO_COMPLETO.zip` preserva archivos que el fundador puede subir juntos a ChatGPT Code. **No asumir que otro chat puede leer las rutas de sandbox de esta sesión si no se vuelven a adjuntar.**

```text
nAIhual_TRASPASO_COMPLETO/
├── README_TRASPASO.md                 <- ESTA MEMORIA; leer primero
├── codigo/
│   ├── C0_ACTUAL/
│   │   ├── index.html                 <- FUENTE VIGENTE del sitio C0
│   │   ├── LEEME_C0.txt               <- Alcance y pasos de publicación
│   │   ├── VERIFICACION_C0.txt        <- Registro de tests locales anteriores
│   │   └── vista-movil.png            <- Captura local
│   └── PROTOTIPOS_HISTORICOS/
│       ├── naihual-prototipo.html     <- Concepto visual/guardianes; no fuente de producción
│       └── naihual-demo-movil.html    <- Demo funcional ilustrativa con enlace Maps
├── fuentes_originales/
│   ├── 0_PROMPT_MAESTRO.md
│   ├── 1_PROCESO.md
│   ├── 2_REGLAS.md
│   ├── 3_PREGUNTAS.md
│   ├── 4_LECCIONES.md
│   ├── nAIhual-Documento-Consolidado-Proyecto-y-Cosmovision.pdf
│   └── nAIhual_Documento_Rector_Construccion_v1_0.pdf
└── entregas_anteriores/
    └── naihual-C0-para-publicar.zip   <- Mismo C0 más README y verificación
```

**Comprobación realizada al preparar este traspaso:** se comprobó presencia de todos los archivos locales anteriores, se abrió el `index.html` y se inspeccionaron sus controles y script; se confirmó que `index.html` dentro de `naihual-C0-para-publicar.zip` coincide **byte por byte** con `/mnt/data/naihual-c0/index.html`, SHA-256:
`63a3ecd1c02c095231e94cc44096492b93c9203389a57882530a73c56bcdff3c`.

**Lo que NO se comprobó en esta preparación:** que Netlify sirve exactamente ese archivo, que la URL responde en la red pública, tiempo de descarga, pruebas en celular de otra persona, ni el resultado de APIs externas.

### Prototipos históricos y cómo usarlos
1. `naihual-prototipo.html`: concepto estético minimalista, verde oscuro y acento lima, modos Kej/No'j/B'atz'/Ajpu, flujos ilustrativos y una URL de Maps. **No fuente de lugares autorizados.**
2. `naihual-demo-movil.html`: demo móvil de «un día» / «tres horas», con rutas de ejemplo y botón Google Maps. **No implica GPS, datos reales, disponibilidad ni IA.**
3. `codigo/C0_ACTUAL/index.html`: versión posterior deliberadamente más pequeña, honesta, sin recomendaciones inventadas. **Esta es la única línea de código de la C0 actual**; no reemplazarla con el prototipo anterior.

### Comportamiento exacto C0 actual
- Inicio (`#inicio`): hero «Conocé un lugar. Conectá con su gente», piloto Antigua, futuras categorías y aviso de alcance.
- Explorar (`#explorar`): formulario de interés, duración y punto de partida opcional; al enviar, crea resumen **solo del texto introducido por el usuario**.
- Tu consulta (`#resumen`): muestra resumen, permite editar, compartir comentario; aclara que no consulta datos reales.
- Propósito (`#proposito`): comunidad, cultura, naturaleza, utilidad.
- Responsive para móvil/escritorio; menú superior e inferior en móvil; navegación sin frameworks.
- Código de `feedback-button`: `navigator.share`, fallback a clipboard seguro, fallback a `https://wa.me/?text=`. No guardar mensajes completos ni enviarlos automáticamente.
- No prometer «funciona offline» para enlaces externos; la interfaz local no tiene dependencias pero navegación pública necesita conexión.

### Registro local de QA histórico (NO confundir con QA pública)
El archivo `VERIFICACION_C0.txt` **documenta**:
- comprobación sintáctica JS con Node;
- pruebas de Chromium/Playwright cargando HTML directamente;
- resoluciones 320×700, 390×844, 768×1024, 1280×800;
- navegación, resumen y edición sin error JS reportado;
- sin scroll horizontal.
En ese informe se advierte que `file://` estaba bloqueado para Chromium, por eso se probó contenido HTML en navegador. **No sustituye HTTPS / Netlify / teléfono ajeno**.

---

## 7. Tablero de circuitos — estado actualizado

| Circuito | Funcionalidad / resultado | Estado real al traspaso |
|---|---|---|
| **C0** | Otra persona entra a web C0 publicada y completa navegación móvil | **Construida y publicada según fundador; no cerrada hasta prueba externa independiente** |
| **C1** | Mostrar cafés curados con filtros y respuesta honesta si faltan datos | **Sin construir** |
| **C2** | Abrir enlaces Google Maps correctos desde cada ficha en móvil | **Sin construir** (las demos anteriores son ilustrativas) |
| **C3** | Contexto responsable con fuente y revisión cultural | **Sin construir** |
| **C4** | Resultados consistentes en español e inglés | **Sin construir** |
| **C5** | Beta con feedback registrado de forma responsable | **Sin construir** (C0 solo abre sistema compartir) |
| **C6** | Consultas libres interpretadas por IA con datos curados | **Sin construir; condicionado a demostrar valor, costo y fiabilidad** |
| **C7** | Creación de contenido basado en experiencias y permisos | **Pospuesto** |
| **C8** | Partners y monetización transparente | **Pospuesto** |

**Orden previsto:** C0 → C1 → C2 → C3 → C4 → C5. C6 solo si mejora el producto frente a filtros/reglas; C7-C8 no bloquean el Alpha.

### Definición de terminado para C0
Una persona ajena al fundador:
1. Abre `https://gregarious-tulumba-42cb05.netlify.app` en su celular, desde su cuenta/dispositivo/red.
2. Puede entrar a **Explorar**, seleccionar **Cafés locales**, elegir **3 horas**, pulsar **Ver mi consulta**, leer el resumen y abrir **Propósito**.
3. Reporta si algo falla; se anota fecha, teléfono/navegador, red, tiempo de carga (meta de atención: ≤5 s, no hecho demostrado) y evidencia autorizada.
4. Solo después se cambia el estado a **✅ verificado con usuario externo**.
5. Si el resultado falla, corregir **C0 solamente** y repetir prueba.

### Mínimo para C1 (solo después de orden expresa)
- Identificar si hay Google Sheet actual. Si no existe, acordar estructura mínima o archivo temporal sin complicar.
- Usar 0-3 fichas reales aportadas y verificadas; no generar negocios ficticios.
- Devolver máximo tres resultados compatibles o mensaje «Aún no tengo datos curados para esa búsqueda».
- Probar rutas con filtros, datos faltantes y contenido visible; documentar resultado.
- No incluir C2 como parte de C1 sin orden: Maps se hace después.

---

## 8. Método de trabajo: fases y entregables

`1_PROCESO.md` habla erróneamente de «11 fases», pero enumera **FASE 0,1,2,...,11 = 12 fases**. No borrar el archivo de origen por el error; documentar la corrección en este traspaso.

| Fase | Objetivo y salida |
|---|---|
| 0 · Quién / qué / para quién | Párrafo de proyecto y roles; fundador único y contactos externos no socios. |
| 1 · Objetivo / prueba final | Escena comprobable, una persona recibe opciones curadas y acción. |
| 2 · Inventario / fuentes de verdad | Tabla dato → ubicación real → editor → si se puede tocar. |
| 3 · Auditoría con datos reales | Tres ejemplos cuando existan; distinguir regla vs excepción. |
| 4 · Circuitos | Tablero C0-C8, disparadores, salidas y estados. |
| 5 · Acceso | Prueba externa de acceso **temprana**. |
| 6 · Plan en PAUSA | Acumular prioridades; no programar hasta orden. |
| 7 · Construcción por bloques | Un circuito, un editor por archivo. |
| 8 · Verificación de punta a punta | Prueba tras publicación, evidencia y medición. |
| 9 · Usuarios reales | Pocas personas beta; recoger errores textuales. |
| 10 · Diseño visual | Integrar identidad del fundador después de validar lógica, sin romperla. |
| 11 · Traspaso / memoria | Actualizar mismo MD de traspaso e historial único. |

**Lecciones de `4_LECCIONES.md` (experiencias metodológicas anteriores, no incidentes confirmados en nAIhual):** acceso de usuario desde el primer día, dos parches → reconsiderar, probar obvio (navegador/cuenta), un editor por archivo, tres ejemplos reales, opción sin IA, «listo» con conteo y evidencia, no borrar funciones que sí sirven, circuitos que registran resultados, medir velocidad, diseño después, informar límites temprano y un historial único.

### Responsables al momento de migrar
| Rol | Estado |
|---|---|
| Fundador/decisor/creador gráfico | Una persona, el usuario de esta conversación. |
| Equipo interno de desarrollo | No hay equipo humano confirmado. |
| Contactos de turismo/contenido/hoteles | Red informal, sin contrato ni acuerdos de partner confirmados. |
| Persona vinculada a Lava Trails | Contacto potencial, sin autorización ni intervención confirmada de la empresa. |
| Revisores culturales | Pendientes, no son requisito para cerrar C0. |
| Beta testers externos | Disponibles potencialmente por red de contactos, prueba aún no documentada. |

**Sobre entrevistas:** se propuso inicialmente una lista extensa de perfiles y entrevistas; el fundador dijo explícitamente **«está demasiado largo... no voy a hacer tantas entrevistas... empiezo más pequeño»**. **No insistir en plan de entrevistas amplio.** Pedir 1 test de acceso y, cuando haga falta, obtener pocas fichas y validaciones puntuales con contactos existentes. La revisión cultural necesaria no debe fingirse, pero puede aplazarse la publicación de contenidos que todavía requieran revisión.

---

## 9. Prompts y contrato de salida propuestos (NO desplegados)

Se diseñaron tres plantillas conceptuales, pero **no hay API, agentes ejecutándose ni endpoint público**. Un solo modelo futuro puede asumir diversos comportamientos sin necesidad de tres agentes autónomos.

### Contrato conceptual
```json
{
  "modo": "kej",
  "titulo": "Tu plan",
  "resumen": "Descripción breve",
  "supuestos": [],
  "items": [],
  "acciones": [
    {"label": "Abrir en Maps", "tipo": "mapa", "url": null}
  ],
  "advertencias": []
}
```
**Acciones posibles:** `mapa`, `partner`, `copiar`, `editar`, `guardar`; validar servidor/front que los URLs proceden de fuentes confiables y `null` no crea CTA roto. En rutas `items` representa paradas; en contenido representa escenas/caption; en comparativas representa opciones.

**Kej:** entradas `ciudad`, `zona`, `origen`, `duracion_horas`, `intereses`, `presupuesto`, `transporte`, `fecha`, `pildoras_disponibles`. Filtrar píldoras curadas, escoger 2-4 paradas cuando realmente existan, estimaciones explícitas, no inventar servicio/horario/precio. Salida JSON + 2-4 acciones útiles si hay datos, o respuesta honesta si no.

**B’atz’:** `experiencia`, `formato`, `plataforma`, `tono`, `duracion_seg`, `objetivo`, `datos_confirmados`. Crear hook, escenas y textos/caption con lo contado por el usuario; no introducir experiencias no vividas ni testimonios; acciones copiar/editar/guardar. Posterior, no C1.

**Ajpu:** `intencion_usuario`, `resultado_previo`, `opciones_disponibles`, `partners_elegibles`, `preferencias`, `objetivo_conversion`. Justificar recomendaciones, 2-4 CTA apropiados, transparencia con patrocinios, prioridad de usuario sobre comisiones, no reservar sin confirmación. Posterior.

**Router de intención (del material de fundador):** puede extraer idioma, tipo de búsqueda, ciudad, categoría, filtros booleanos, origen/destino mediante salida estructurada. **No se necesitan necesariamente dos llamadas de modelo**; comparar reglas fijas, una llamada y dos llamadas con pruebas reales. Propuestas n8n/webhook `POST /naihual/ask` y `/places` **no están implementadas**.

---

## 10. Diseño: el fundador aporta artes (no bloquear desarrollo)

### Dirección visual temporal (NO identidad oficial)
Los prototipos emplean minimalismo tecnológico, verde profundo, crema, verde lima, sans limpia, pantallas despejadas. El fundador manifestó que le gusta bastante, pero **él hará la parte gráfica**. No aprobar logotipos/guardianes/colores definitivos por inferencia.

### Lista de archivos visuales propuesta
| Arte | Exportación sugerida | Necesidad |
|---|---|---|
| Logotipo e isotipo | SVG vectorial; claro/oscuro/monocromo | Al integrar marca |
| Símbolos Kej, B’atz’, Ajpu, No’j | 4 SVG; PNG transparente 1024×1024 opcional | Tras revisión cultural |
| Colores y tipografía | HEX, familias/pesos/licencias | Sistema visual |
| Hero móvil | WebP 1080×1920 | Home final |
| Fotografías de experiencias/lugares | WebP/JPG 1200×800; crédito y permiso | Fichas |
| Marcadores personalizados Maps | SVG y PNG 48×48 | Solo mapa integrado futuro |
| Iconos PWA | PNG 192×192 y 512×512 | Cuando PWA |
| Imagen de compartir | 1200×630 PNG/JPG | Distribución |

No exigirle todos estos artes ahora. El frontend debe permitir sustituir imágenes y CSS sin rehacer selección de lugares o rutas. Respetar derechos de autor y autorización al usar fotografías de personas, comunidades o símbolos.

---

## 11. Riesgos, errores e incongruencias identificadas

| ID | Hallazgo | Estado y acción futura |
|---|---|---|
| R01 | `1_PROCESO.md` dice 11 fases, enumera 12 | **Error de conteo confirmado**; registrar, no alterar archivo original sin autorización. |
| R02 | PDF presenta tradición maya y perfiles de nawales sin citas bibliográficas suficientes | **No validado externamente**; pedir fuentes y validación pertinente antes de publicar afirmaciones rituales. |
| R03 | Término `Nik'aj` como cero maya | **A revisar específicamente**, sin afirmar que sea cierto o falso sin fuente. |
| R04 | Modelo de producto amplio vs Alpha cafés muy estrecho | **Alcance reducido por decisión posterior**; no forzar reels ni múltiples sectores en C1. |
| R05 | PDF propone Wix/n8n/Gemini, rector Vite/TS/Cloudflare, demo actual HTML/Netlify | **No confundir propuesta con implementación**; la realidad actual es HTML en Netlify según fundador. |
| R06 | «Antigua protegida de gentrificación» frente a promoción turística | **Tensión ética no resuelta**: definir criterios verificables antes de decir que una ruta genera beneficio social. |
| R07 | Acceso externo probado vs sitio compartido | **No equivalentes**; el fundador subió URL, pero no hay segunda persona documentada. |
| R08 | Google Maps links vs Google Maps integrado | **Distinto circuito**: C2 links, mapa embebido futuro y sujeto a condiciones/costo. |
| R09 | `logs.user_message` registra contenido libre | **Riesgo de privacidad**; no recolectar ni almacenar por defecto. |
| R10 | Dos llamadas de IA «baratas» y GPT-3.5 mencionados | **No verificado ni aprobado**; probar costo/estado actual de modelos antes. |
| R11 | Partners, reserva y experiencia de Lava Trails | **No confirmados**; no poner logos, ofertas, afiliación ni horarios sin consentimiento y fuente. |
| R12 | «100% gratis» con IA/API/GMaps embebido | **No garantizable**; diferenciar hosting y enlaces gratuitos de APIs con posibles cuotas. |
| R13 | Diseño «al final» y fundador trabajando gráficos | **Compatible**: C0 usa estilo temporal; integración de marca cuando no rompa lógica. |
| R14 | Supuesta ubicación actual de usuarios | **No asumir**; el visitante puede escribir origen, GPS no implementado. |

**Limitaciones de verificación de esta sesión de traspaso:** no hubo navegación web para consultar Netlify ni documentos oficiales externos. Los archivos PDF/MD fueron inspeccionados localmente. No se han comprobado precios actuales, licencias, regulación guatemalteca o fuentes primarias de cosmovisión.

---

## 12. Historial resumido de la conversación y decisiones

| Fecha | Acción, decisión o entrega |
|---|---|
| **2026-10-15** | Fundador presentó proyecto nAIhual: turismo práctico + creación de contenido + monetización; quería web gratis, píldoras, respuestas accionables y pocos pasos. Se elaboró blueprint con 3 personas, 5 entradas, flujos A/B/C, Home/Modos/Resultados/Leads, monetización, backlog y prompts Kej/B’atz’/Ajpu. |
| **2026-10-15** | Impuso **PAUSA hasta CONSTRUYE**, cero invención, rigor, protección de comunidad, naturaleza y cultura. Agregó 4 guardianes, 5 intents alternativos, Sheets y propuesta n8n. |
| **2026-10-15** | Confirmó: **la gente y la cultura son el centro, NO la creación de contenido**. Ordenó construir demo visual; se entregó `naihual-prototipo.html` con gráfica temporal. |
| **2026-10-15** | Pidió demo de celular con Maps; se entregó `naihual-demo-movil.html`, ilustrativo, Google Maps mediante links (no API embebida). |
| **2026-10-17** | Compartió NotebookLM URL `https://notebook.google.com/notebook/70f17462-3cc4-4baf-990c-209fca3ae9e2/preview`; no se pudo acceder en esa sesión. Después adjuntó **6 archivos** originales que sí se leyeron. |
| **2026-10-17** | Se revisaron PDF y 5 MD, detectando error 11 vs 12 fases, verificaciones culturales faltantes, diferencias de stack y alcance. |
| **2026-10-17** | Fundador dijo que por ahora trabaja solo, con red de contactos; pidió ruta tecnológica, lista de entrevistas y PDF. Se creó PDF rector 16 pp. |
| **2026-10-17** | Fundador rechazó la carga de tantas entrevistas: **empezar muy pequeño**. Dio orden explícita **CONSTRUYE C0**. |
| **2026-10-17** | Se construyó `naihual-c0/index.html`, screenshot, ZIP y reporte de verificación local. Se instruyó subir mediante Netlify Drop. |
| **2026-10-17** | Fundador compartió **https://gregarious-tulumba-42cb05.netlify.app** diciendo que ya lo había subido. El asistente pidió prueba con otro celular/otra persona. |
| **2026-10-17** | Fundador pidió **archivo MD exhaustivo para migrar a ChatGPT Code**. Este traspaso se confecciona con los archivos locales disponibles y sin afirmar despliegue comprobado. |

---

## 13. Preguntas pendientes: no abriles una entrevista al fundador

Solicitar una sola cosa cuando sea imprescindible para cerrar circuito actual:

1. **C0 (inmediata):** ¿una persona distinta de vos entró a Netlify desde su celular, navegó y te dijo si funcionó? Registrar detalle, sin entrevista extensa.
2. **C1 (cuando autorice):** ¿existe Google Sheet con cafés reales o partimos de 0? Pedir 0-3 fichas disponibles, no 20.
3. Más adelante: ¿quién revisará versión inglesa? ¿Dónde irán fuentes de cultura? ¿Cuáles artes hay listos? ¿Qué cuenta gestiona dominio/hosting? ¿Hay presupuesto API? Resolver cuando el circuito lo requiera.

No exigir investigación extensa, socios, grupo grande de beta, contratos ni branding antes de C0.

---

## 14. Procedimiento para ChatGPT Code en el nuevo chat

1. **Leer este archivo completo.** Si viene ZIP, abrir `codigo/C0_ACTUAL/index.html`, los cinco `.md` originales y PDFs según necesidad; no emplear prototipos históricos como código de producción.
2. **Contestar en PAUSA**, resumiendo en pocas líneas: propósito, stack real, URL pública que informó el fundador, estado C0 y bloqueo para avanzar.
3. Antes de cambiar código, esperar `CONSTRUYE C#`. Aclarar alcance solo si hay ambigüedad imprescindible.
4. Si se da `CONSTRUYE C1`, usar el index actual como base, preservar rutas existentes y pedir fuentes reales mínimas para los cafés. Crear una versión verificable, probar localmente y aclarar qué no se pudo desplegar/probar.
5. Después de cada circuito: anotar cambios, evidencia, diferencias, pendientes, archivos modificados, cómo volver atrás, sin repetir nombres de documentos/versiones confusos.
6. **No publicar como hecho un resultado que no se haya comprobado.**

### Mensaje corto para pegar en el nuevo chat (opcional)
> Estoy migrando nAIhual. Adjunté `nAIhual_TRASPASO_MAESTRO.md` y, si está disponible, `nAIhual_TRASPASO_COMPLETO.zip` con el código C0, fuentes originales, PDFs y prototipos históricos. Leé primero el traspaso y la C0 vigente. Aplicá `PAUSA` hasta que yo ordene `CONSTRUYE C#`. No cambies el hosting ni reescribas lo que funciona sin justificarlo. Decime brevemente qué comprendiste, qué verificaste y qué falta comprobar antes de cerrar C0.

---

## 15. Procedencia y jerarquía de información

**Primera fuente:** declaraciones explícitas y posteriores del fundador en esta conversación. Cuando corrige una decisión anterior (por ejemplo, «no tantas entrevistas»), **gana la decisión posterior**.

**Segunda fuente:** documentos originales del fundador (archivo y página):
- `0_PROMPT_MAESTRO.md`: rol y reglas de comunicación.
- `1_PROCESO.md`: 12 fases enumeradas (0-11).
- `2_REGLAS.md`: comandos, fuente única, metodología de verificación.
- `3_PREGUNTAS.md`: banco de preguntas, **no obligación de hacerlas todas**.
- `4_LECCIONES.md`: experiencias previas y prioridades de QA.
- `nAIhual-Documento-Consolidado-Proyecto-y-Cosmovision.pdf`: pp. 1-2 visión/stack; pp. 2-4 cosmovisión/tabla y salvaguardas. Los contenidos culturales necesitan verificación independiente.

**Tercera fuente:** entregables de análisis generados antes:
- `nAIhual_Documento_Rector_Construccion_v1_0.pdf`, 16 pp.: mapa de producto/circuitos; **es anterior a la creación C0 y al Netlify real**. Puede estar desactualizado donde dice «C0 no iniciado», «PAUSA» o Cloudflare candidato.
- Primer blueprint escrito en conversación: tres personas, cinco ideas, flujos, prompts y monetización; esas partes se conservan como antecedentes, no como órdenes de implementación.

**Cuarta fuente:** código/artefactos actuales:
- `codigo/C0_ACTUAL/index.html`: **autoridad sobre lo implementado**.
- `VERIFICACION_C0.txt`: informe de tests anteriores; no evidencia de la web pública.
- Netlify URL: referencia **aportada por el fundador**.

### Regla final de mantenimiento
Cuando exista una nueva prueba o decisión, **actualizar este mismo documento** y dejar constancia en un solo historial; no reescribir el pasado como si todo se hubiera confirmado. Señalar fecha, estado, fuente, cambio y quién lo verificó.

**FIN DEL TRASPASO — Estado recomendado del nuevo chat: PAUSA; C0 pendiente de prueba de acceso externa.**
