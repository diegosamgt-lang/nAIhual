# Historial de nAIhual

## Traspaso completo a Claude — 17 de octubre de 2026, Guatemala

**Pedido:** reunir todo lo disponible en un ZIP para migrar a Claude. El fundador rechazó el diseño actual; no se interpreta la migración como aprobación visual ni autorización para seguir construyendo. Se establece PAUSA para el siguiente asistente.

**Se conserva:** snapshot del código actual (incluidas modificaciones locales no presentes en el HEAD del checkout), C0 intacta, HTML completos y simplificados, fuentes de datos vacías, pruebas, biblioteca con licencia, documentación vigente, adjuntos originales intactos y extraídos, documentos agregados al main remoto, entregas previas, capturas técnicas disponibles, configuración reutilizable sin credenciales e historia de commits en Git bundle.

**Estado para continuidad:** aplicación 0.1.3; 12 pruebas Node y 10 escenarios de navegador controlados en la última comprobación de funcionalidad, más pruebas específicas de las vistas HTML. Ninguna de ellas demuestra IA conectada, GPS físico, proveedores externos de rutas/mapa funcionando o compatibilidad satisfactoria con el visor real del fundador. El diseño no está aprobado. Netlify y main no se modifican para preparar el traspaso.

**Límites:** las capturas pegadas por el fundador y la transcripción literal íntegra del chat no están disponibles como archivos exportables; se incluye el contexto escrito y los errores descritos. Los archivos de originales son archivo histórico; el único traspaso e historial vigentes están en `proyecto_actual/docs/` dentro del paquete. No se copian archivos de autenticación ni valores de variables de entorno.

## 0.1.3 — 17 de octubre de 2026, Guatemala

**Evidencia:** nueva captura del fundador con vista «Index», HTML sin formato y aviso genérico de error del visualizador. El `index.html` de la aplicación depende de CSS y módulos vecinos; no es el archivo adecuado para renderizar aislado. Las pruebas en Chromium anteriores no prueban compatibilidad con el visualizador real de ChatGPT.

**Replanteamiento:** en lugar de otra carga del proyecto completo dentro del visor se creó `entregas/panel-editor-simple.html`, con estilos en cada elemento y contenedor propio. No requiere hojas CSS, módulos, formularios, iframes, navegación por URL, solicitudes de red ni cambios en la ubicación del navegador. Incluye diseño, ayuda nativa desplegable, chat guiado local y propuesta/confirmación de coordenadas. El área del mapa se identifica explícitamente como no conectada; no se simulan cartografía, GPS, rutas ni IA. La aplicación completa y la C0 permanecen separadas y sin cambios de lógica.

**Generación:** `npm run preview:html` copia ahora la vista simple a `entregas/editor-chatgpt.html`. Las vistas de la aplicación completa se conservan como `entregas/naihual-editor.html` y `entregas/editor-completo.html`.

**Comprobación:** tres tamaños, todas las conexiones bloqueadas, cero solicitudes, confirmación de destino y chat correctos; diseño y ayuda también con JavaScript desactivado. Se probó renderizar solo el contenido de body, sin head ni estilos de body: el contenedor conserva colores, tipografía y controles, sin errores ni desbordamiento. Captura real de esa prueba en `entregas/editor-simple.png`. Sigue pendiente la respuesta del visor real del fundador; no se da por comprobada.

**Fuente:** rama `codex/naihual-base-mapa`, commit `71bd094d99f1cc6b09ac8855245189a433ddfd4f`. SHA-256 del HTML simple: `f383ff6bc4c523c6e64fce0aa85dcaf1d4c80771f7c84a43ccc4fe89689f1276`. No se modificó Netlify ni main. Reversión: vista completa anterior disponible en commit `eb0d98fb93c3bca52b5fafadcdfa567430213908`.

## 0.1.2 — 17 de octubre de 2026, Guatemala

**Orden:** «SEGUI CONSTRUYENDO», dentro del alcance vigente de Explorar, mapa y conversación. No se activaron APIs de pago, datos turísticos nuevos ni publicación en producción.

**Cambios:** conversación guiada con ayuda contextual, consulta del destino y de la ubicación disponible; interpretación de coordenadas escritas, siempre como propuesta manual que exige pulsar «Usar este destino»; coordenadas inválidas rechazadas; ninguna consulta local se envía al proveedor de IA. Se agregaron estados de destino/ubicación/recorrido, botón Centrar mapa y borrado del chat que cancela respuestas pendientes y conserva el destino/GPS hasta que el usuario los quite. El destino se vuelve a dibujar si la biblioteca del mapa carga después de seleccionarlo.

**Evidencia:** 12 pruebas Node y 10 escenarios de Chromium pasaron. Los casos nuevos verifican que proponer y confirmar coordenadas no activa GPS, ruta ni IA, y que una respuesta anterior no reaparece después de borrar el chat. HTML directo del editor probado a 320, 390 y 1280 px con TODAS las conexiones bloqueadas; ayuda, propuesta, confirmación y estados funcionan sin GitHub o backend. La captura del panel muestra el mapa no disponible en esa prueba, sin fingir cartografía. Build y generador HTML correctos; C0 preservada con su SHA original.

**Entrega:** código y HTML en rama `codex/naihual-base-mapa`, commit `eb0d98fb93c3bca52b5fafadcdfa567430213908`. HTML directo remoto descargado con HTTP 200 e integridad comprobada: SHA-256 `215463173944a93f402578b66faa3a8e023cd3abcb703fa88feeac71ca8a5989`. Captura en `entregas/panel-explorar.png`; versión completa en `entregas/naihual-editor.html`. No se afirma que el editor de ChatGPT se haya actualizado automáticamente. Netlify y `main` no se modificaron. Sigue pendiente comprobar proveedores públicos, GPS físico e IA real. Reversión: entrega anterior `887668665392d6925a85da76f6c4fc2d980ec71e`.

## Corrección del HTML del editor — 17 de octubre de 2026, Guatemala

**Evidencia del fundador:** captura del visor de ChatGPT mostrando que el cargador remoto no pudo obtener el panel desde GitHub. Se retira ese enfoque para la vista del editor.

**Cambio:** `npm run preview:html` genera ahora además `entregas/editor-chatgpt.html` con el marcado, estilos, catálogo y lógica local incluidos. No contiene iframe de carga ni solicitud a GitHub. Únicamente el mapa intenta cargar Leaflet 1.9.4 por CDN con integridad SHA-384; si el visor lo bloquea, el panel permanece funcional. La versión `naihual-editor.html` conserva la biblioteca incluida y la web de producción no se modifica.

**Verificación:** dentro de un iframe con solo `allow-scripts`, bloqueando TODAS las conexiones, pasaron navegación Inicio/Explorar, conversación por botones y Enter, selección por coordenadas y preguntas desplegables a 320, 390 y 1280 px. Sin errores JavaScript y sin intentos de obtener GitHub, catálogo o backend. No se declara verificado el mapa externo o GPS del visor real. El HTML completo se entrega en el mensaje para su previsualización, sin envoltorio de carga remota ni ZIP.

## Adaptación a HTML integrado — 17 de octubre de 2026, Guatemala

**Orden:** el fundador pidió ver el panel en el editor HTML de ChatGPT, sin descargar paquetes repetidamente. Se creó `preview.mjs` y `npm run preview:html`, que generan `entregas/naihual-editor.html` a partir de las fuentes existentes. Incluye estilos, Leaflet con licencia, código y catálogo. No requiere imports, servidor, archivos vecinos ni backend para conversar. El mapa y las rutas siguen usando Internet; el GPS depende de los permisos del visor. C0 y la web original no se sustituyen.

**Ajustes para visor aislado:** navegación interna por eventos para no abandonar `srcdoc`; controles de conversación y coordenadas por botones/Enter, sin depender de permisos para enviar formularios. Se detectaron y corrigieron estas dos restricciones en las pruebas. Navegación, chat, ayuda y selección de destino pasaron en un iframe con solo `allow-scripts` en 320, 390 y 1280 px. No se probaron permisos GPS reales del editor de ChatGPT.

**Entrega:** HTML fuente en commit `887668665392d6925a85da76f6c4fc2d980ec71e`, rama `codex/naihual-base-mapa`. Solicitud HTTPS a raw.githubusercontent.com respondió 200; SHA-256 `9bd917418ed131b5f3881a6f6bb43d7fbd591f7193dbb8f1522242bded9a69a9`, idéntico al HTML probado. `entregas/editor-chatgpt.html` es un bloque corto que lo carga dentro de un iframe, sin descarga manual. El navegador de pruebas rechazó la conexión externa por `ERR_CERT_AUTHORITY_INVALID` con el proxy; no se desactivó TLS. La integración del bloque se comprueba con una respuesta controlada del HTML previamente descargado por HTTPS.

**Límite de interfaz:** la sesión no ofrece herramientas de Canvas/editor. Entregar un bloque HTML no prueba que ChatGPT muestre un botón Vista previa ni que permita sus conexiones de red. No se afirma haber abierto el editor de ChatGPT ni haber publicado el sitio.

## 0.1.1 — 17 de octubre de 2026, Guatemala

**Orden:** «construye, sigue añadiendo contenido al panel»; el fundador confirmó que se refiere a **Explorar de nAIhual**. Sites y Themely no expusieron herramientas utilizables; se trabajó sobre el código existente sin atribuirles cambios.

**Cambios:** guía de tres pasos para destino, origen y ruta; seis preguntas desplegables sobre conversación, catálogo vacío, permiso de ubicación, fallos de conexión, pantalla bloqueada y detención del seguimiento; recordatorio de respetar accesos, propiedad y residentes. Se conservaron mapa, conversación, rutas y C0, sin añadir puntos ni afirmaciones culturales no verificadas. Archivos de producto modificados: `index.html`, `styles.css` y versión en `package.json`.

**Comprobado:** build estático correcto; ocho escenarios existentes de navegador pasaron con servicios/GPS controlados. Se abrieron las seis preguntas y comprobaron los tres pasos en 320, 390, 768 y 1280 px sin desbordamiento ni errores JS. C0 dentro del paquete conserva su SHA-256 original. No se volvió a ejecutar una IA o recorrido físico, ni se afirmó que los proveedores públicos estén verificados.

**Entrega:** rama `codex/naihual-base-mapa`, commit `866a7577a9675d6bfbda6eacf803925f1f840557`. ZIP descargado por HTTPS con HTTP 200, íntegro e idéntico al construido: SHA-256 `3787562ba05f448bc08c171b54d6e4768b2d13ff3941f490cc0175366ac6efbf`. Ruta en la rama: `entregas/naihual-para-netlify.zip`; captura real del contenido: `entregas/panel-explorar.png`. `main` y Netlify no se modificaron. Reversión de esta ampliación: usar la entrega anterior del commit `1b01b504963a7d27b228519b70af03e5bc230027`.

## 0.1.0 — 17 de octubre de 2026, Guatemala

**Autorización:** el fundador cambió la prioridad de cafés a estructura del bot, mapa integrado y conversación sobre ubicaciones; autorizó construir con la alternativa más sencilla. Este bloque se registra como **C1 reformulado: base de mapa + conversación**. No activa automáticamente los antiguos C3–C8.

**Cambios:** C0 adjunta preservada byte por byte en `c0/index.html`; nueva web con Inicio, Explorar, Tu consulta y Propósito; mapa Leaflet/OpenStreetMap; destinos por mapa o coordenadas; catálogo inicialmente vacío; conversación por reglas; conector de interpretación Gemini opcional en backend Node; rutas peatonales FOSSGIS; GPS voluntario, avance e indicaciones en primer plano; pausa por mala precisión/posición vieja; aviso de desvío; detención del GPS; build estático para Netlify.

**Evidencia actual:** verificación SHA-256 de la C0 preservada: `63a3ecd1c02c095231e94cc44096492b93c9203389a57882530a73c56bcdff3c`. Leaflet 1.9.4 verificado contra la integridad SHA-512 publicada por npm. Nueve pruebas de Node pasaron (lógica, validación de datos y rutas, rechazo de IDs inventados por IA, fallback, HTTP y protección de archivos). Navegador Chromium probado en 320×700, 390×844, 768×1024 y 1280×800, con GPS/teselas/rutas controlados. Se corrigió un desbordamiento del menú a 320 px. No se ejecutó una IA real ni se verificaron proveedores públicos de mapa/rutas.

**Limitación externa:** solicitudes HTTPS a `tile.openstreetmap.org` y `routing.openstreetmap.de` rechazadas por el proxy del entorno: `CONNECT tunnel failed, response 403`. No es evidencia de que el proveedor esté caído. No se desactivó TLS ni verificación de paquetes.

**Estado:** 🟡 construido y probado localmente con servicios simulados; pendiente de conectividad real, prueba caminando en teléfono, datos curados e IA con cuenta/modelo/presupuesto confirmados. El fundador reportó que la C0 funciona; no aportó detalles de una prueba externa independiente. No se publicó esta versión ni se declaró cerrado C1.

**Reversión:** usar `c0/index.html` como entrada para volver a la C0 recibida; la publicación existente de Netlify no se tocó. Los nuevos archivos están en el checkout actual; no se hicieron commits ni push.

**Comprobación de entrega:** ocho escenarios de navegador pasaron: cuatro tamaños, permiso denegado, servicios caídos/hosting sin API, cancelación de destino durante una consulta y GPS impreciso/vencido con callback después de detener. El `dist/` generado se sirvió como sitio estático real: se comprobó el fallback sin backend y el acceso a C0. Se reinició el servidor de esta tarea y `POST /api/chat` respondió HTTP 200 en modo guiado. Paquete `/workspace/naihual-base-mapa-0.1.0.zip`: 16 archivos públicos, sin backend, documentos internos ni claves.

**Configuración de entorno guardada como borrador:** `install_script` (validación y build), `start_skill` (arranque y límites), y dominios de red `tile.openstreetmap.org` + `routing.openstreetmap.de`, conservando los presets. Persistencia confirmada por la herramienta; requiere revisar/guardar y publicar el entorno en sus ajustes. No aplicado al runtime ni publicado durante esta entrega. Es independiente de publicar el sitio en Netlify.

### Corrección de entrega — misma fecha

Los enlaces locales y `sandbox:` anteriores no permitieron descargar al fundador. Para atender su orden expresa de entregar una descarga, se verificó permiso de subida y se creó la rama remota `codex/naihual-base-mapa` desde el `main` remoto actualizado, sin modificar `main` ni Netlify. Commit: `1b01b504963a7d27b228519b70af03e5bc230027`. Incluye la base, pruebas, dependencias, C0 preservada y `entregas/naihual-para-netlify.zip`. No se incluyó este traspaso ni secretos en la rama de entrega; se conservaron los documentos que el fundador ya había agregado al `main` remoto.

Descarga real probada: `https://github.com/diegosamgt-lang/nAIhual/raw/refs/heads/codex/naihual-base-mapa/entregas/naihual-para-netlify.zip`, HTTP 200. ZIP descargado íntegro con `index.html` y SHA-256 idéntico al construido: `7501f1056864b2f5d0a83be1bfbb10f7738149551f0c4e368aa5b4492a9a2d31`. Esto verifica entrega del archivo, no publicación o navegación real. La comprobación de un visor externo raw.githack.com fue bloqueada por el proxy; no se comparte como vista verificada.
