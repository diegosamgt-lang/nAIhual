# nAIhual
**nAIhual** es un **agente inteligente turístico-cultural**[1][2]. Funciona como puente digital para conectar viajeros con la cultura, las comunidades y el territorio de Guatemala de manera consciente, auténtica y respetuosa, fusionando el concepto de *nahual* con la *inteligencia artificial*

## Base actual

Web móvil con mapa integrado, conversación guiada, selección de destino y seguimiento peatonal experimental en primer plano. Los cafés dejaron de ser el primer bloque por decisión del fundador del 17 de octubre de 2026. La C0 recibida se conserva intacta en `c0/index.html`.

No hay puntos curados cargados, API de IA configurada ni publicación de esta nueva versión. El mapa base y las rutas necesitan Internet. No se usa Google My Maps ni se sincronizan listas de Google Maps en este bloque.

## Desarrollo

Node 22 o superior. Sin instalación de paquetes: Leaflet 1.9.4 está incluido con licencia e integridad registrada en `vendor/leaflet/INTEGRITY.txt`.

```sh
npm start
```

El servidor usa el puerto 3000 y escucha en la interfaz local por defecto. `PORT` y `HOST` permiten cambiarlo. El GPS requiere HTTPS en publicación; el navegador permite pruebas locales. Pedir ubicación es una acción expresa. Cambiar de pantalla, ocultar la pestaña o pulsar detener cancela el seguimiento y borra la posición en memoria.

```sh
npm test
npm run build
```

`npm test` ejecuta las pruebas de lógica y HTTP con Node. Con Python Playwright y Chromium instalados, `python tests/browser_smoke.py` prueba la UI contra el servidor iniciado. Estas pruebas simulan GPS, teselas y rutas: no verifican los proveedores externos ni una caminata real.

## Datos

`data/places.json` es la única fuente de puntos públicos para esta base. Empieza vacía. Cada ficha necesita: `id`, `name`, `category`, `city`, `lat`, `lng`, `sourceUrl` HTTPS, `reviewedAt` (AAAA-MM-DD) y `status: "verified"`; `address` es opcional. La marca de verificación es editorial: el software no investiga ni certifica la fuente. No cargar datos privados o ubicaciones sensibles. La web rechaza fichas incompletas; no completa datos faltantes.

Una selección manual en el mapa se distingue de una ficha curada. No se conserva al recargar. La conversación y ubicación viven en memoria, sin almacenamiento local ni base de datos.

## Mapa y rutas

- Leaflet local + teselas de `tile.openstreetmap.org`, con atribución visible a OpenStreetMap.
- Rutas a pie: `routing.openstreetmap.de/routed-foot/route/v1/foot/…`. No se usa un perfil de automóvil como si fuera peatonal.
- Al pulsar calcular se envían origen y destino al proveedor. El GPS posterior actualiza el indicador local; no consulta una ruta en cada movimiento. Hay una espera mínima de 5,5 segundos entre consultas por sesión.
- La precisión baja o una posición vencida pausan las indicaciones. Los desvíos requieren recalcular manualmente. No hay voz, seguimiento en segundo plano, funcionamiento sin conexión ni garantía de accesibilidad o seguridad del recorrido.

Los servicios públicos tienen políticas de uso y disponibilidad propias. Antes de una beta pública, verificar el recorrido con el proveedor real y revisar sus condiciones actuales: https://operations.osmfoundation.org/policies/tiles/ y https://routing.openstreetmap.de/about.html. Este entorno devolvió un bloqueo de proxy 403 para los servicios; las pruebas controladas no sustituyen esa comprobación. Para tráfico de producción se debe evaluar un proveedor con capacidad y condiciones apropiadas.

## Conector de IA preparado, pendiente de activación

El servidor Node incluye `POST /api/chat`. Sin configuración responde con reglas, y así se identifica en pantalla. La IA opcional solo interpreta intención e IDs de puntos existentes; el texto de respuesta y las ubicaciones salen del catálogo, no de hechos generados por el modelo. Un fallo del proveedor vuelve al modo guiado.

La activación requiere un acceso API de Gemini, presupuesto aprobado y un modelo disponible verificado en la cuenta. Configurar de forma segura `GEMINI_API_KEY` y `GEMINI_MODEL` en el servidor; nunca en el frontend, Git o chat. No se eligió un modelo por suponer disponibilidad. Las suscripciones de consumidor no acreditan acceso API. La integración se probó con respuestas simuladas, no con una API real.

El servidor limita solicitudes por dirección de conexión y tamaño de mensaje, no registra conversaciones y no entrega sus archivos privados. Es una base de desarrollo; una API pública de pago requiere límites de gasto y protección adecuada en el despliegue. No exponer este servidor con credenciales hasta preparar ese despliegue.

## Publicación

Para una vista local del panel en editores de HTML, `npm run preview:html` genera `entregas/editor-chatgpt.html` desde `entregas/panel-editor-simple.html`. Esta vista usa estilos en los elementos, no requiere red, hojas CSS, módulos, navegación por URL ni formularios. Incluye presentación, preguntas desplegables, conversación guiada local y destinos por coordenadas con confirmación. El mapa en vivo y el GPS no se ejecutan en esta vista. El marcado también conserva su aspecto al renderizar solo el cuerpo del documento. La aplicación completa permanece en `dist/`; la adaptación completa a un archivo se conserva en `entregas/naihual-editor.html` y `entregas/editor-completo.html`.

`npm run build` produce `dist/`, que contiene solamente archivos públicos. Se puede subir **esa carpeta** a Netlify Drop. `netlify.toml` configura el mismo destino si después se conecta el repositorio. No subir la raíz del repositorio, archivos `.env` ni documentos internos.

La publicación estática funciona en modo guiado. **Netlify Drop no ejecuta `server.mjs` ni activa la IA.** El frontend usa reglas locales si no existe `/api/chat`. Activar la IA requerirá un backend alojado de manera segura, como paso separado. Esta entrega no cambia la web que ya está publicada.

Contexto y decisiones vigentes: [traspaso maestro](docs/nAIhual_TRASPASO_MAESTRO.md). Evidencia y cambios: [historial único](docs/HISTORIAL.md).
