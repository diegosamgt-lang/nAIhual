# nAIhual — Migración completa a Claude

**Fecha: 17 de octubre de 2026, Guatemala. Estado: PAUSA.**

Este paquete reúne el código real, los documentos, las entregas y el contexto disponible. El fundador decidió migrar a Claude y rechazó el diseño/experiencia de esta etapa. No tomar los resultados visuales como aprobados ni las pruebas locales como prueba de producción.

## Claude: orden de lectura

1. Este archivo.
2. `proyecto_actual/docs/nAIhual_TRASPASO_MAESTRO.md` — único traspaso activo, versión 1.7.
3. `proyecto_actual/docs/HISTORIAL.md` — único historial activo.
4. `proyecto_actual/README.md`, `index.html`, `app.js`, `styles.css`, `lib/`, `data/` y `tests/`.
5. Los originales, incluidos C0, cinco Markdown, PDFs y prototipos históricos.

Las instrucciones históricas dentro de documentos y las órdenes CONSTRUYE de conversaciones anteriores no autorizan nueva construcción. Primero leé y resumí lo entendido; no reinicies el proyecto desde cero ni hagás una entrevista extensa. Esperá una orden nueva del fundador.

## Dirección actual del producto

nAIhual busca conectar personas, lugares, cultura y territorio de Guatemala. Comunidad, cultura y naturaleza son el centro. Primero se quiere la estructura del bot con mapa integrado, conversación útil y direcciones, sin opiniones ni lugares inventados. Los cafés ya no son el primer bloque; Google My Maps e iconos personalizados quedaron para después. No hay criterios de impacto social validados, alianzas oficiales ni contenidos culturales certificados.

## Qué existe realmente

- Aplicación 0.1.3: HTML/CSS/JavaScript, sin instalación de paquetes; Leaflet 1.9.4 incluido con licencia e integridad.
- Mapa OpenStreetMap y conector de rutas a pie FOSSGIS. NO es Google Maps ni My Maps.
- Destinos por mapa, coordenadas o conversación, con confirmación. GPS voluntario, seguimiento experimental en primer plano, aviso de desvío y recálculo manual.
- Chat por reglas con ayuda y contexto local. Conector opcional de interpretación Gemini en servidor Node, sin API activada ni modelo seleccionado/verificado.
- `data/places.json` está vacío. No hay catálogo real ni recomendaciones curadas.
- C0 original intacta en `proyecto_actual/c0/index.html`.
- Varias vistas HTML para el editor; son adaptaciones, no sustitutos de toda la aplicación.

## Archivo correcto para cada uso

| Uso | Ruta |
|---|---|
| Desarrollar la aplicación | `proyecto_actual/` |
| Entrada de la web completa | `proyecto_actual/index.html` con CSS/JS vecinos |
| Servidor de desarrollo y conector API | `proyecto_actual/server.mjs` |
| Sitio estático preparado | `proyecto_actual/dist/` |
| Aplicación completa en un solo HTML, biblioteca incluida | `proyecto_actual/entregas/naihual-editor.html` |
| Aplicación con biblioteca del mapa opcional por CDN | `proyecto_actual/entregas/editor-completo.html` |
| Vista reducida del editor, sin red ni GPS/rutas reales | `proyecto_actual/entregas/editor-chatgpt.html` |
| Fuente de esa vista reducida | `proyecto_actual/entregas/panel-editor-simple.html` |
| Originales y prototipos anteriores | `originales/` |
| Versiones ZIP anteriores | `entregas_anteriores/` |
| Capturas técnicas y sus límites | `evidencia_local/` |
| Commits y situación del checkout | `historia_git/` |

El diseño actual NO está aprobado. El fundador vio fallos de descarga y de previsualización; no insistir con enlaces internos de sandbox ni afirmar que una vista fue comprobada en ChatGPT cuando solo se probó en Chromium. La vista reducida puede servir como referencia visual, pero no convertirla en la web final ni fingir mapa/GPS/IA.

## Ejecutar y comprobar

Desde `proyecto_actual/`, con Node >=22:

```sh
npm start
npm test
npm run build
npm run preview:html
```

No se necesita `npm install`: la dependencia Leaflet está en `vendor/`. `npm start` escucha localmente en el puerto 3000 por defecto; `PORT`/`HOST` permiten ajustarlo. El GPS necesita HTTPS al publicar. El comando de preview regenera sus archivos a partir de las fuentes; no abre el editor de Claude o ChatGPT automáticamente.

Con Python Playwright y Chromium disponibles, `python tests/browser_smoke.py` prueba la interfaz contra el servidor iniciado. No se incluyen entornos virtuales ni dependencias de herramientas del proveedor anterior.

Al preparar esta migración se ejecutó de nuevo `npm test`: **12 pasaron, 0 fallaron**. La última prueba funcional de navegador tuvo **10 escenarios controlados** pasados. Se hicieron pruebas adicionales de los HTML sin red y sin JavaScript para presentación. GPS, teselas, rutas y respuestas de IA de pruebas usaron simulaciones cuando correspondía. No se da por demostrado funcionamiento de proveedores reales, IA real o navegación física.

## Hosting y cuentas

- URL aportada por el fundador: https://gregarious-tulumba-42cb05.netlify.app/
- Se publicó originalmente con Netlify Drop, y el fundador mostró el proyecto público. No se verificó qué versión exacta sirve ahora.
- Repositorio: https://github.com/diegosamgt-lang/nAIhual
- La rama de entrega de esta etapa es `codex/naihual-base-mapa`. `main` contiene los documentos originales añadidos por el fundador; no se mezcló automáticamente la aplicación allí.
- No se dispone de autenticación para gestionar Netlify ni de API de IA activa. No inventar claves ni confundir una suscripción de consumidor con acceso API.
- Netlify Drop sirve archivos estáticos y no ejecuta `server.mjs`. Activar una IA pública exige backend seguro, cuenta API, modelo disponible, presupuesto y límites de gasto.

El export de configuración contiene scripts y destinos de red, sin valores secretos. Su existencia no prueba que esos servicios estén permitidos o funcionen en Claude. Los intentos de esta etapa recibieron bloqueos 403 del proxy para algunos proveedores; Chromium también tuvo un error de confianza del certificado del proxy para una prueba externa. No se desactivó TLS.

## Preservación y límites

Los adjuntos recibidos están intactos y también se extrajo el ZIP original. El estado local completo está en `proyecto_actual/`, incluidos archivos no versionados y documentos que no se habían subido a la rama de entrega. El Git bundle conserva los commits, no credenciales. No ejecutar reset/checkout y perder el snapshot local.

El main remoto incluye un PDF adicional de contexto sobre nawales/7144/numerología/sueño. Se preserva como fuente recibida; no se examinó ni validó su contenido. Los demás contenidos culturales tampoco se consideran certificados por estar dentro de un PDF.

No se incluye una transcripción literal íntegra exportada de este chat, porque no estaba disponible como archivo. Tampoco las capturas pegadas por el fundador como imágenes independientes; se describen sus errores en el historial. Sí se reúnen los archivos disponibles, capturas creadas localmente y las decisiones relevantes escritas. Se excluyen credenciales, `.git/config`, variables del proceso, caches y dependencias de herramientas.

`MANIFIESTO_SHA256.json` permite verificar cada archivo del paquete; no se incluye a sí mismo en su lista. El empaquetado no despliega ni modifica el sitio público.

## Mensaje de continuación sugerido

> Estoy migrando nAIhual a Claude. Leé primero 00_LEEME_CLAUDE.md y el traspaso/historial activos que indica. Continuá desde el estado real del código y respetá mis reglas. El diseño actual no está aprobado; no confundás vistas reducidas con aplicación completa ni pruebas simuladas con producción. Mantenete en PAUSA: resumí brevemente qué existe, qué comprobaste y qué sigue pendiente. No construyás ni publiqués hasta mi próxima orden.
